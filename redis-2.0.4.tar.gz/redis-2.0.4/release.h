#define REDIS_GIT_SHA1 "1c145073"
#define REDIS_GIT_DIRTY "       0"
